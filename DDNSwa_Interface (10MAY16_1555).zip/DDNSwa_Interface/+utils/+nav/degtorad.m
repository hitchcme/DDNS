function rad = degtorad(deg)

	rad = deg * pi / 180;

end

