function deg = radtodeg(rad)

	%rad = deg * pi / 180;
	deg = rad / ( pi / 180);

end