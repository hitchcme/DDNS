function [STATUS] = hide(PATHINPUT,BOOL)
%HIDE Summary of this function goes here
%   Detailed explanation goes here
	if nargin > 1
		if BOOL ==  true
			HSTR = '+h';
		else
			HSTR = '-h';
		end
	else
		HSTR = '+h';
	end
	STATUS = fileattrib(PATHINPUT,HSTR);
end