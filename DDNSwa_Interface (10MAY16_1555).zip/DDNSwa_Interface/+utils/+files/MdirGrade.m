function [ALL,TBL1s,RDRFILES] = MdirGrade(MRSROOT)
%MDIRGRADE List Compatible & Incompatible Mission Directories
%   MRSROOT => Miss(ion)s Root directory, but I liked MRS better...

DIRS = strcat(MRSROOT,cellstr(ls(MRSROOT)));
if size(DIRS,1) >= 2
	DIRS(1:2) = [];
end

%Strip Dont-Care Files & Directories
LINE_matches = regexprep(DIRS,{	'[0-9][0-9][0-9][A-Z]',...
								'[0-9][0-9][A-Z]'},...
									'~');
LINE_matches = regexprep(LINE_matches,MRSROOT,'');
%Strip accidental Matches
LINE_matches = regexprep(LINE_matches,{	'~ [A-Z]',...
										'~[A-Z]',...
										'~ [0-9]',...
										'~[0-9]',...
										'~-',...
											},'Not this either');
for i=1:size(LINE_matches,1)
	LINE_match_wv = char(LINE_matches(i,1));
	LINE_match_wv = LINE_match_wv(1);
	LINE_matches(i) = cellstr(LINE_match_wv);
end
LINE_matches = ismember(LINE_matches,'~');
DIRS = DIRS(LINE_matches);

%List Directories within acceptable directories

for i=1:size(DIRS,1)
	DIRS1 = strcat(DIRS(i),'\',cellstr(ls(strcat(char(DIRS(i)),'\*'))));
	DIRS1wv = cellstr(upper(ls(strcat(char(DIRS(i)),'\*'))));
	if size(DIRS1,1) >= 2
		DIRS1(1:2) = [];
		DIRS1wv(1:2) = [];
	end
	
	DIRS1wv = regexprep(DIRS1wv,{	'[0-9][0-9][0-9][A-Z]-[A-Z]',...
									'[0-9][0-9][A-Z]-[A-Z]',...
										},'~');
	DIRS1wv = regexprep(DIRS1wv,'~[0-9]','This should probably be in a subdirectory');
	LINE_matches = ismember(DIRS1wv,'~');
	DIRS1 = DIRS1(LINE_matches);
	
	if exist('DIRS2','var')
		DIRS2 = [DIRS2;DIRS1];
	else
		DIRS2 = DIRS1;
	end
end

DIRS = DIRS2;

for i=1:size(DIRS,1)
	cellstr(ls(strcat(char(DIRS(i)),'\*')));
	DIRS1 = strcat(DIRS(i),'\',cellstr(ls(strcat(char(DIRS(i)),'\*'))));

	if size(DIRS1,1) >= 2
		DIRS1(1:2) = [];
	end
	
	if exist('DIRS2','var')
		DIRS2 = [DIRS2;DIRS1];
	else
		DIRS2 = DIRS1;
	end
end

DIRS = DIRS2;

%Strip Roots
for i=1:size(DIRS,1)
	DIRSwv = utils.misc.strsplit(regexprep(char(DIRS(i)),'\',','),',');
	if size(DIRSwv,2) <= 3
		DIRS(i) = cellstr('~');
	end
end
DIRS = DIRS(~ismember(DIRS,'~'));


for i=1:size(DIRS,1)
	DIRSwv = utils.misc.strsplit(regexprep(char(DIRS(i)),'\',','),',');
	DIRSwv = upper(char(DIRSwv(4)));
	DIRSwv = regexprep(DIRSwv,{	'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9]',...
								'[0-9][0-9][A-Z]-[A-Z][0-9][0-9]',...
								'[0-9][0-9][0-9][A-Z]-[A-Z][0-9]',...
								'[0-9][0-9][A-Z]-[A-Z][0-9]',...
									},'~');
	DIRSwv = regexprep(DIRSwv,{ '~ ',...
								'~[A-Z]',...
								'~[0-9]',...
									},'Nope');
	DIRS1(i) = cellstr(DIRSwv);
	
end

DIRS = DIRS(ismember(DIRS1,'~'));

for i=1:size(DIRS,1)
	MISSIONDIRS = cellstr(ls(char(strcat(DIRS(i),'\*'))));
	MISSIONDIRSwv = upper(MISSIONDIRS);
	TP_present = sum(sum(ismember(MISSIONDIRSwv,'TP'))) > 0;
	TPDocs_present = sum(sum(ismember(MISSIONDIRSwv,'TP DOCS'))) > 0;
	Weibel_present = sum(sum(ismember(MISSIONDIRSwv,'WEIBEL'))) > 0;
	if TP_present & TPDocs_present & Weibel_present
		'This One is so-far-so-good';
	else
		DIRS(i) = cellstr('~');
	end
end

DIRS = DIRS(~ismember(DIRS,'~'));
clear DIRS1;
for i=1:size(DIRS,1)
	DIRSwv = cellstr(ls(char(strcat(DIRS(i),'\*'))));
	if size(DIRSwv,1)>=2
		DIRSwv(1:2) = [];
	end
	DIRSwv1 = regexprep(DIRSwv,{	'[tT][pP] [dD][oO][cC][sS]',...
									'[tT][pP]',...
									'[wW][eE][iI][bB][eE][lL]',...
										},'~');
	DIRSwv = cellstr(strcat(DIRS(i),'\',DIRSwv(ismember(DIRSwv1,'~'))));
	if ~exist('DIRS1','var')
		DIRS1 = DIRSwv;
	else
		DIRS1 = [DIRS1;DIRSwv];
	end
end

DIRS = DIRS1;
clear DIRSwv
for i=1:size(DIRS,1)
	FILESFP = strcat(DIRS(i),'\',cellstr(ls(char(DIRS(i)))));
	FILES = cellstr(ls(char(DIRS(i))));
	if size(FILES,1) >= 2
		FILES(1:2) = [];
		FILESFP(1:2) = [];
	end
	
	% Mark the Field Sheets
	FILES_oiind = regexprep(upper(FILES),{	'[0-9][0-9][0-9][A-Z]-[A-Z][0-9]  F40OUTSD.DOCX',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9]  F40OUTSD.DOCX',...
											'[0-9][0-9][A-Z]-[A-Z][0-9]  F40OUTSD.DOCX',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9]  F40OUTSD.DOCX',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] F40OUTSD.DOCX',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] F40OUTSD.DOCX',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] F40OUTSD.DOCX',...													'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] F40OUTSD.[dD][oO][cC][xX]',...
												},'~');
	% Mark the Table 1 entry
	FILES_oiind = regexprep(FILES_oiind,{	'[0-9][0-9][0-9][A-Z]-[A-Z][0-9]TABLE1.TXT',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9]TABLE1.TXT',...
											'[0-9][0-9][A-Z]-[A-Z][0-9]TABLE1.TXT',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9]TABLE1.TXT',...
												},'~');
	%Mark the Weibel Processed directory
	FILE_oiind = regexprep(FILES_oiind,{	'PROCESSED DATA',...
											'PROCESSED',...
												},'~');
	
	FILES = FILES(ismember(FILE_oiind,'~'));
	FILESFP = strcat(DIRS(i),'\',FILES);
	if isempty(FILES)
		DIRS(i) = cellstr('~');
	end
	
	if exist('DIRSwv','var')
		DIRSwv = [DIRSwv;FILESFP];
	else
		DIRSwv = FILESFP;
	end
	
end

DIRS = DIRSwv;

for i=1:size(DIRS,1)
	if exist('DIRSTBL','var')
		DIRSTBL = [DIRSTBL;utils.misc.strsplit(regexprep(char(DIRS(i)),'\',','),',')];
	else
		DIRSTBL = utils.misc.strsplit(regexprep(char(DIRS(i)),'\',','),',');
	end
end

if exist('DIRSTBL','var')
	DIRSTBL = cell2table(DIRSTBL);
	DIRSTBL.DIRSTBL1 = [];
	DIRSTBL.DIRSTBL2 = [];
	DIRSTBL.DIRSTBL3 = [];
end

for i=1:size(DIRS,1)
	MDIRCNT = sum(sum(ismember(DIRSTBL.DIRSTBL4,char(DIRSTBL.DIRSTBL4(i)))));
	if MDIRCNT < 3
		DIRS(i) = cellstr('~');
	end
end

DIRS = DIRS(~ismember(DIRS,'~'));

for i=3:3:size(DIRS,1)
	RDRFILES = cellstr(ls(char(strcat(DIRS(i),'\*.asc'))));
	RDRFILE_matches = regexprep(RDRFILES,{	'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR][0-9].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9][0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
											'[0-9][0-9][A-Z]-[A-Z][0-9] [rR][dD][rR] [0-9] [iIpP][mMuU][pPsS][aAhH][cCeE][tTrR].[aA][sS][cC]',...
												},'~');

	RDRFILES = RDRFILES(ismember(RDRFILE_matches,'~'));
	if isempty(RDRFILES)
		DIRS(i-2:1:i) = cellstr('~');
	else
		DIRS = [DIRS;cellstr(strcat(DIRS(i),'\',RDRFILES))];
		DIRS(i) = cellstr('~');
	end
end
	
DIRS = sort(DIRS(~ismember(DIRS,'~')));

%build separate RADAR files table
RDRFILES = [];
for i=1:size(DIRS,1)
	DIRSwv = utils.misc.strsplit(regexprep(char(DIRS(i)),'\',','),',');
	RDRFILEwv = sum(sum(ismember(upper(char(DIRSwv(5))),'Weibel'))) > 0;
	if exist('RDRFILES','var')
		RDRFILES = [RDRFILES;RDRFILEwv];
	else
		RDRFILES = RDRFILEwv;
	end
end

TBL1s = DIRS(~ismember(RDRFILES,1)); %Just for now
TBL1s = TBL1s(2:2:size(TBL1s,1));
RDRFILES = DIRS(ismember(RDRFILES,1));
ALL = DIRS;

