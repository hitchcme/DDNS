function ImportLatest(MRSROOT)

	[~,~,RDRFILES] = utils.files.MdirGrade(MRSROOT);
	
	for i=1:size(RDRFILES,1)

			FILE = dir(char(RDRFILES(i)));
			if exist('DATE','var')
				DATE = [DATE;FILE.date];
			else
				DATE = FILE.date;
			end
	end
	
	DATEwv = datetime(regexprep(cellstr(DATE),' [0-9][0-9]:[0-9][0-9]:[0-9][0-9]',''));
	LatestRDRFILES = RDRFILES(ismember(DATEwv,max(DATEwv)));

	for i=1:size(LatestRDRFILES)
		import_TableRADAR(char(LatestRDRFILES(i)));
	end
	
	