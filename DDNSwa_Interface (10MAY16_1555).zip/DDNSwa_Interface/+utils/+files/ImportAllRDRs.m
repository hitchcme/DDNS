function ImportAllRDRs(MRSROOT)

	[~,~,RDRFILES] = utils.files.MdirGrade(MRSROOT)
	for i=1:size(RDRFILES,1)
		RDRFILES(i)
		try
			import_TableRADAR(char(RDRFILES(i)));
		catch e
			e
		end
		fileattrib('./.tmp','-h')
	end

end

