function [STATUS] = Pullprj(PROJECT)
%Pullprj:  Pull project from \\Tkserver\tdc_data\Hitch\MATLAB\$PROJECT

	USER = getenv('USERNAME');
	DIRDELIM = '\';
	myROOT = strcat('C:\Users\',USER,'\Documents\MATLAB\');
	myExtROOT = '\\Tkserver\tdc_data\Hitch\MATLAB\';
	myutilsROOT = strcat(myROOT,'+utils');
		
	PRJPath = strcat(myROOT,PROJECT);
	ExtPRJPath = strcat(myExtROOT,PROJECT);

	copyfile(ExtPRJPath,PRJPath,'f');
	
	utils.project.updateUtils(strcat(PRJPath,'\+utils'),myutilsROOT);
	cd(PRJPath);

	rm_asvs(PRJPath);
	rm_asvs(ExtPRJPath);
	
	

function rm_asvs(PRJPATH)
	
	ASVPATH = strcat(PRJPATH,'\*~');
	AUTOSAVES = ls(ASVPATH);
	AUTOSAVES = cellstr(strcat(PRJPATH,'\',AUTOSAVES));
	ASVPATH = strcat(PRJPATH,'\*asv');
	AUTOSAVES = [AUTOSAVES;cellstr(strcat(PRJPATH,'\',ls(ASVPATH)))];
	
	UTILSDIRS = strcat(PRJPATH,'\+utils\');
	UTILSDIRS = cellstr(strcat(UTILSDIRS,ls(UTILSDIRS),'\'));
	UTILSDIRS(size(UTILSDIRS,1)) = [];
	UTILSDIRS(size(UTILSDIRS,1)) = [];
	
	for i=1:size(UTILSDIRS,1)
		ASVPATH = strcat(char(UTILSDIRS(i)),'*asv');
		if size(char(ls(ASVPATH)),1)
			AUTOSAVES = [AUTOSAVES;cellstr(strcat(char(UTILSDIRS(i)),ls(ASVPATH)))];
		end
		ASVPATH = strcat(char(UTILSDIRS(i)),'*~');
		if size(char(ls(ASVPATH)),1)
			AUTOSAVES = [AUTOSAVES;cellstr(strcat(char(UTILSDIRS(i)),ls(ASVPATH)))];
		end
	end

	for i=1:size(AUTOSAVES,1)
		if size(char(AUTOSAVES(i)),2)-1 ~= size(char(PRJPATH),2)
			delete(char(AUTOSAVES(i)));
		end
	end
	
	