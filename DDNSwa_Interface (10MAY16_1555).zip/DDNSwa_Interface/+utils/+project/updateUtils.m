function [STATUS] = updateUtils(SRC,DEST)
%UPDATEUTILS: Put a copy of +utils in the UserROOT of MATLAB
	try
		rmdir(DEST);
		mkdir(DEST);
	catch e
		'';
	end
	copyfile(SRC,DEST,'f');
end

