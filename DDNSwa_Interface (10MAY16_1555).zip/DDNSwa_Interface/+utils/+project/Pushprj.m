function [STATUS] = Pushprj(PROJECT)
%Push:  Push project to \\Tkserver\tdc_data\Hitch\MATLAB\$PROJECT


	
	USER = getenv('USERNAME');
	DIRDELIM = '\';
	myROOT = strcat('C:\Users\',USER,'\Documents\MATLAB\');
	myExtROOT = '\\Tkserver\tdc_data\Hitch\MATLAB\';
	myutilsROOT = strcat(myROOT,'+utils');
	
	
	PRJPath = strcat(myROOT,PROJECT);
	ExtPRJPath = strcat(myExtROOT,PROJECT);
	ExtPRJtmpPath = strcat(ExtPRJPath,'\.tmp');
	PRJarcvs = strcat(myROOT,'archives\',PROJECT,' (archives)\');
	ExtPRJarcvs = strcat(myExtROOT,'archives\',PROJECT,' (archives)\');
	
	FILES = dir(ExtPRJPath);
	DATE = utils.misc.strsplit(char(max(datetime(vertcat(FILES.date)))),' ');
	TIME = utils.misc.strsplit(char(regexprep(DATE(2),':',' ')));
	TIME = strcat(TIME(1),TIME(2));
	DATE = utils.misc.strsplit(char(regexprep(upper(DATE(1)),'-',' ')));
	DATE(3) = cellstr(num2str(str2double(DATE(3))-floor(str2double(DATE(3))/1000)*1000));
	WDF =	~isnan(str2double(DATE(1))) && size(char(DATE(1)),2)==4;
	if WDF
		%WDF==True, then the year is in the wrong spot
		%	and the date is probably in the years place
		DATE(1) = cellstr(num2str(str2double(DATE(1))-floor(str2double(DATE(1))/1000)*1000));
		DATE1wv = DATE(3);
		DATE3wv = DATE(1);
		DATE(3) = DATE3wv;
		DATE(1) = DATE1wv;
	end
	% DATE(2) should be a three character month
	WDF = ~isnan(str2double(DATE(2)));
	if WDF
		DATE2wv = str2double(DATE(2));
		MONTHS = utils.misc.strsplit('JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC');
		DATE(2) = cellstr(MONTHS(DATE2wv));
	end
	DATE = strcat(DATE(1),DATE(2),DATE(3));
	
	rm_asvs(PRJPath)
	rm_asvs(ExtPRJPath)
	
	
	if ~exist(strcat(myROOT,'archives'),'dir')
		mkdir(strcat(myROOT,'archives'));
	end
	if ~exist(strcat(myExtROOT,'archives'),'dir')
		mkdir(strcat(myExtROOT,'archives'));
	end
	if ~exist(PRJarcvs,'dir')
		mkdir(PRJarcvs);
	end
	if ~exist(ExtPRJarcvs,'dir')
		mkdir(ExtPRJarcvs);
	end
	
	utils.files.hide(strcat(myROOT,'archives'),true);
	utils.files.hide(strcat(myExtROOT,'archives'),true);
	
	EXEC_FileName = ls(strcat(ExtPRJPath,'\*.exe'));
	EXEC_ExtPATH = strcat(ExtPRJPath,'\',EXEC_FileName);
	EXEC_PATH = strcat('C:\Users\',USER,'\Desktop\',EXEC_FileName);
	NoEXE = logical(sum(size(char(EXEC_FileName)) < 1));
	
	if ~NoEXE && exist(EXEC_PATH,'file') && exist(EXEC_ExtPATH,'file')
		delete(EXEC_PATH);
		copyfile(EXEC_ExtPATH,EXEC_PATH,'f');
	end
		
	if NoEXE
		ZIPFILENAM = char(strcat(PRJarcvs,PROJECT,' (',DATE,'_',TIME,').zip'));
		ZIPFILENAM_Remote = char(strcat(ExtPRJarcvs,PROJECT,' (',DATE,'_',TIME,').zip'));
	else
		ZIPFILENAM = char(strcat(PRJarcvs,PROJECT,' (',DATE,'_',TIME,'_with_exec).zip'));
		ZIPFILENAM_Remote = char(strcat(ExtPRJarcvs,PROJECT,' (',DATE,'_',TIME,'_with_exec).zip'));
	end
	zip(ZIPFILENAM,ExtPRJPath);
	copyfile(ZIPFILENAM,ZIPFILENAM_Remote,'f');
	copyfile(PRJPath,ExtPRJPath,'f');
	
	%delete the remote executable after archival
	if exist(EXEC_ExtPATH)
		if abs(size(char(EXEC_ExtPATH),2)-size(char(ExtPRJPath),2)) ~= 1
			delete(EXEC_ExtPATH);
		end
	end
	
	%don't be storing the tmp directory in the zip
	if exist(ExtPRJtmpPath,'dir')
		rmdir(ExtPRJtmpPath,'s');
	end
	
	utils.project.updateUtils(strcat(PRJPath,'\+utils'),myutilsROOT)
	
	if ~strfind(upper(USER),'HITCHCOCK')
		'This isnt Hitch!'
		rmdir(PRJarcvs,'s');
	end
	

function rm_asvs(PRJPATH)
	
	ASVPATH = strcat(PRJPATH,'\*~');
	AUTOSAVES = ls(ASVPATH);
	AUTOSAVES = cellstr(strcat(PRJPATH,'\',AUTOSAVES));
	ASVPATH = strcat(PRJPATH,'\*asv');
	AUTOSAVES = [AUTOSAVES;cellstr(strcat(PRJPATH,'\',ls(ASVPATH)))];
	
	UTILSDIRS = strcat(PRJPATH,'\+utils\');
	UTILSDIRS = cellstr(strcat(UTILSDIRS,ls(UTILSDIRS),'\'));
	UTILSDIRS(size(UTILSDIRS,1)) = [];
	UTILSDIRS(size(UTILSDIRS,1)) = [];
	
	for i=1:size(UTILSDIRS,1)
		ASVPATH = strcat(char(UTILSDIRS(i)),'*asv');
		if size(char(ls(ASVPATH)),1)
			AUTOSAVES = [AUTOSAVES;cellstr(strcat(char(UTILSDIRS(i)),ls(ASVPATH)))];
		end
		ASVPATH = strcat(char(UTILSDIRS(i)),'*~');
		if size(char(ls(ASVPATH)),1)
			AUTOSAVES = [AUTOSAVES;cellstr(strcat(char(UTILSDIRS(i)),ls(ASVPATH)))];
		end
	end

	for i=1:size(AUTOSAVES,1)
		if size(char(AUTOSAVES(i)),2)-1 ~= size(char(PRJPATH),2)
			delete(char(AUTOSAVES(i)));
		end
	end
	
	